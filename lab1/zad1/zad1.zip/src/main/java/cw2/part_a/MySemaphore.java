package cw2.part_a;

public interface MySemaphore {

    void P();

    void V();
}
